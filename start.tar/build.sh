#!/bin/bash

set -e

echo "[+] Updating and installing required packages..."
apt update && apt upgrade -y
apt install -y \
    dnsmasq \
    tcpdump \
    vim \
    ncdu \
    curl \
    wget \
    net-tools \
    docker.io \
    docker-compose \
    docker-compose-plugin

echo "[+] Starting Docker Compose build..."

docker compose -f docker-compose.yml build
echo "[✓] Docker containers built successfully."

echo "[+] Attempting to start containers with no VPN config..."
docker compose -f docker-compose.yml up -d  openvpn_client || true

echo "[i] If the VPN config is missing, the container will exit with an error (as expected)."
docker ps -a | grep openvpn_client